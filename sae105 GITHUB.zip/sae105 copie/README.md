NOTION : https://guttural-quart-b47.notion.site/Opquast-SA-1-05-Ta-passion-en-images-1-2e3548b4a75a818ab3c5dde3f09fec9a?source=copy_link

LOCALHOST XAMPP:

Afin de tester mon site web dans un environnement proche d’un serveur réel avant sa mise en ligne, j’ai utilisé le logiciel XAMPP, qui permet de créer un serveur local sur mon ordinateur.
Dans un premier temps, j’ai rassemblé tous les fichiers nécessaires au fonctionnement de mon site (fichiers HTML, CSS, JavaScript ainsi que les images) dans un seul dossier que j’ai nommé projet-sae106. Cette organisation facilite évite les erreurs de liens entre les fichiers dans XAMPP.
Ensuite, je me suis rendu dans le dossier racine du serveur Apache fourni par XAMPP. Sur macOS, ce dossier s’appelle htdocs et se trouve à l’emplacement suivant :
/Applications/XAMPP/xamppfiles/htdocs/.
J’y ai copié l’intégralité du dossier projet-sae106. Cette étape est indispensable pour que le serveur Apache puisse accéder aux fichiers du site.
Une fois les fichiers en place, j’ai lancé l’application XAMPP. J’ai démarré le service Apache en cliquant sur le bouton Start. J’ai attendu que l’indicateur passe au vert, ce qui confirme que le serveur est bien actif.
Enfin, pour vérifier que l’installation fonctionnait correctement, j’ai ouvert un navigateur web et saisi l’adresse suivante :
http://localhost/projet-sae106/.
Le site s’est affiché correctement, ce qui m’a permis de confirmer que l’installation locale était réussie et que l’ensemble des fichiers (styles CSS, scripts JavaScript et images) étaient bien pris en compte.

URL: http://mariojoy.projetsmmichamps.fr/sae105