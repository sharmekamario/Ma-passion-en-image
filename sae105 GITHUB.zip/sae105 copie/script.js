document.addEventListener("DOMContentLoaded", function() {
    // Petit message dans la console pour être sûre que le script se lance bien
    console.log("Site prêt !")

    //  1. FONCTIONS POUR L'AFFICHAGE 

    // ça c'est pour afficher mes fenêtres modales
    // j'enleve la classe CSS 'Cache' qui a un display none
    function afficherElement(id) {
        const el = document.getElementById(id)
        if (el) el.classList.remove("Cache")
    }

    // l'inverse pour recacher les éléments
    function cacherElement(id) {
        const el = document.getElementById(id)
        if (el) el.classList.add("Cache")
    }

    // Fonction de secours pour tout fermer d'un coup
    function toutFermer() {
        cacherElement("FenetreZoom")
        cacherElement("FenetreMentions")
    }

    //  2. GESTION DES CLICS 

    // Je récupere toute les croix de fermeture
    // et je boucle dessus pour que chaque bouton ferme bien la fenetre
    const croix = document.querySelectorAll(".BoutonFermer")
    for (let i = 0; i < croix.length; i++) {
        croix[i].addEventListener("click", toutFermer)
    }

    // Si on clique sur le fond noir ça ferme aussi
    window.addEventListener("click", function(e) {
        if (e.target.classList.contains("Fenetre")) {
            toutFermer()
        }
        // Pour les mentions légales en bas
        if (e.target.id === "BoutonLegal") {
            afficherElement("FenetreMentions")
        }
    })

    // LA FONCTION POUR LE ZOOM DES IMAGES
    // C'est ici que je remplis la fenetre vide avec les infos de l'artiste cliquer
    function lancerZoom(imageSrc, titre, description, source, urlArticle) {
        const img = document.getElementById("ImgZoom")
        const txt = document.getElementById("TxtZoom")
        
        img.src = imageSrc
        img.alt = titre
        
        let piedDePage = ""
        
        // J'ai ajouté une condition pour afficher soit le lien soit la source
        if (urlArticle) {
            piedDePage = `<div style="margin-top: 15px; padding-top: 10px; border-top: 1px solid #333;">
                            <a href="${urlArticle}" target="_blank" style="color:#5db5f0; text-decoration:underline; font-weight:bold;">
                                Lire l'article de la source
                            </a>
                          </div>`
        } else if (source) {
            piedDePage = `<div style="margin-top: 15px; padding-top: 10px; border-top: 1px solid #333;">
                            <small style="color:#aaa;">Source : ${source}</small>
                          </div>`
        }
        
        // Je met tout le contenu ds le HTML
        txt.innerHTML = `<strong>${titre}</strong><br><span style='color:#ccc'>${description}</span>${piedDePage}`
        
        afficherElement("FenetreZoom")
    }


    //  3. GENERATION DE MA GRILLE D'ARTISTES 

    const grille = document.getElementById("GrilleArtistes")
    const info = document.getElementById("InfoSurvol")

    // Je verifie que la grille existe 
    if (grille && typeof collectionMusique !== 'undefined') {
        grille.innerHTML = "" // on vide au cas ou

        // Boucle for pour créé chaque carte d'artiste automatiquement
        for (let i = 0; i < collectionMusique.length; i++) {
            const artiste = collectionMusique[i]
            const carte = document.createElement("figure")
            carte.className = "CarteGalerie"
            
            // Je construis ma carte en HTML.
            carte.innerHTML = `
                <div class="ConteneurImgGalerie" title="Agrandir">
                    <img src="${artiste.image}" alt="${artiste.alt}">
                </div>
                <figcaption class="ContenuGalerie">
                    <h3>${artiste.titre}</h3>
                    <a href="${artiste.lienSpotify}" target="_blank" class="LienSpotify">Écouter 🎵</a>
                </figcaption>
                <div class="BoiteRaison"><strong>Pourquoi ?</strong><br>${artiste.raison}</div>
            `

            // Clic sur l'images pour ouvrir en grand
            carte.querySelector(".ConteneurImgGalerie").addEventListener("click", function(e) {
                e.stopPropagation() // pour eviter les bugs de clic
                lancerZoom(artiste.image, artiste.titre, artiste.description, artiste.source, artiste.sourceUrl)
            })

            // Effet quand on passe la souris dessus
            carte.addEventListener("mouseenter", function() {
                info.textContent = artiste.titre + " : " + artiste.description
                info.style.color = "white"
            })
            carte.addEventListener("mouseleave", function() {
                info.textContent = " Scrollez à droite et passez la souris sur une image pour voir les détails."
                info.style.color = "#aaa"
            })

            grille.appendChild(carte)
        }
    }


    //  4. LE CARROUSEL 

    const zoneCarrousel = document.getElementById("ZoneCarrousel")

    if (zoneCarrousel && typeof secretsStudio !== 'undefined') {
        zoneCarrousel.innerHTML = ""
        
        // Je prépare la structure du carrousel avec une boucle
        let html = "<div class='ConteneurCarrousel'><div class='PisteCarrousel'>"
        
        for (let i = 0; i < secretsStudio.length; i++) {
            const s = secretsStudio[i]
            html += `
            <figure class='CartePiste'>
                <div class='ConteneurImgPiste' title="Agrandir">
                    <img src='${s.image}' class='ImgPiste' alt='${s.alt}'>
                </div>
                <figcaption class='ContenuPiste'>
                    <div class="EntetePiste">
                        <div class="GroupeTitre">
                            <h3>${s.titre}</h3>
                            <span class="BadgeArtiste">${s.artiste}</span>
                        </div>
                        <div class="LecteurSpotify">${s.embedCode}</div>
                    </div>
                    <div class="SectionInfos">
                        <div class="TitreInfo">💡 Fun Fact</div>
                        <p class="TexteInfo">${s.funFact}</p>
                        <div class="TitreInfo" style="margin-top: 15px;">🎛️ La Conception</div>
                        <p class="TexteInfo">${s.conception}</p>
                    </div>
                </figcaption>
            </figure>`
        }
        html += "</div><button class='BoutonCarrousel Prev'>❮</button><button class='BoutonCarrousel Next'>❯</button></div>"
        zoneCarrousel.innerHTML = html

        // Logique pour faire bouger le carrousel
        const piste = zoneCarrousel.querySelector(".PisteCarrousel")
        const max = secretsStudio.length
        let index = 0

        function bouger(direction) {
            index += direction
            if (index < 0) index = max - 1 // on revient a la fin
            if (index >= max) index = 0    // on revient au début
            // Je deplace la piste de 100% sur la gauche
            piste.style.transform = "translateX(-" + (index * 100) + "%)"
        }

        zoneCarrousel.querySelector(".Prev").addEventListener("click", function() { bouger(-1) })
        zoneCarrousel.querySelector(".Next").addEventListener("click", function() { bouger(1) })

        // Zoom aussi pour les images du carrousel
        const imagesPiste = zoneCarrousel.querySelectorAll(".ConteneurImgPiste")
        for(let i=0; i<imagesPiste.length; i++) {
            imagesPiste[i].addEventListener("click", function() {
                const s = secretsStudio[i]
                lancerZoom(s.image, s.titre, s.artiste, s.source, s.sourceUrl)
            })
        }
    }


    //  5. EFFET D'APPARITION AU SCROLL 

    // ça c'est pour que les sections arrive tout doucement quand on descend
    const obs = new IntersectionObserver(function(entries) {
        for (let i = 0; i < entries.length; i++) {
            // Si l'élément est visible a l'écran on met la classe 'Visible'
            if (entries[i].isIntersecting) entries[i].target.classList.add("Visible")
        }
    }, { threshold: 0.1 })

    const els = document.querySelectorAll(".Apparition")
    for (let i = 0; i < els.length; i++) obs.observe(els[i])


    //  5. LE FORMULAIRE ET LE STOCKAGE DES SONS 

    const form = document.getElementById("FormulaireAjout")
    const grilleSons = document.getElementById("GrilleSons")
    const MESSONS = "mes_sons_v1" // clé pour enregistrer ds le navigateur

    // fct pour créer le bloc d'un nouveau son
    function ajouterSon(nom, lien, raison) {
        const article = document.createElement("article")
        article.className = "CarteSon Visible"
        article.innerHTML = `
            <div class='EnteteSon'>
                <div class='AvatarLettre'>${nom.charAt(0).toUpperCase()}</div>
                <div class='NomAuteur'>${nom}</div>
            </div>
            <p class='CitationSon'> "${raison}" </p>
            <iframe src='${lien}' width='100%' height='80' frameBorder='0' allow='encrypted-media'></iframe>
        `
        grilleSons.prepend(article) // on l'ajoute au début
    }

    if (grilleSons) {
        // 1. Je affiche les sons par défaut ds data.js
        if (typeof defaultData !== 'undefined') {
            for (let i = 0; i < defaultData.length; i++) {
                ajouterSon(defaultData[i].nom, defaultData[i].link, defaultData[i].raison)
            }
        }
        
        // 2. Je récupére ce qui est ds le local storage
        const save = JSON.parse(localStorage.getItem(MESSONS) || "[]")
        for (let i = 0; i < save.length; i++) {
            ajouterSon(save[i].nom, save[i].lien, save[i].raison)
        }
    }

    // Je gere l'envoi du formulaire ici
    if (form) {
        form.addEventListener("submit", function(e) {
            e.preventDefault() // pour pas que la page se recharge
            const nom = document.getElementById("Prenom").value
            let lien = document.getElementById("LienSpotify").value
            const raison = document.getElementById("Raison").value

            // J'ai du bidouiller les liens spotify pour que ça marche ds l'iframe
            // pcq il faut que ça soit un lien 'embed'
            if (lien.indexOf("/track/") !== -1) {
                lien = lien.replace("/track/", "/embed/track/").split("?")[0]
            } else {
                return alert("Le lien Spotify est pas bon !")
            }

            ajouterSon(nom, lien, raison)
            
            // Je sauvegarde ds le local storage pour pas perdre les sons au refresh
            const liste = JSON.parse(localStorage.getItem(MESSONS) || "[]")
            liste.push({ nom: nom, lien: lien, raison: raison })
            localStorage.setItem(MESSONS, JSON.stringify(liste))
            
            form.reset() // on vide les champs
        })
    }


    //  7. MENTIONS LEGALES (Auto) 

    // ça c'est pour pas écrire tout les crédits à la main ds le html
    const zoneCredits = document.querySelector(".TexteLegal")
    
    if (zoneCredits && typeof collectionMusique !== 'undefined') {
        let html = "<hr><h4>Crédits Images</h4><ul>"
        
        for (let i = 0; i < collectionMusique.length; i++) {
            if (collectionMusique[i].source) {
                html += `<li>${collectionMusique[i].titre} : ${collectionMusique[i].source}</li>`
            }
        }
        if (typeof secretsStudio !== 'undefined') {
            for (let i = 0; i < secretsStudio.length; i++) {
                if (secretsStudio[i].source) {
                    html += `<li>${secretsStudio[i].titre} : ${secretsStudio[i].source}</li>`
                }
            }
        }
        
        html += "</ul>"
        zoneCredits.innerHTML += html
    }

})
